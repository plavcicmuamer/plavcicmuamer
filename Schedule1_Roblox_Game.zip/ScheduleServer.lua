-- ServerScriptService/ScheduleServer
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TaskModule = require(ReplicatedStorage:WaitForChild("TaskModule"))
local Players = game:GetService("Players")

-- RemoteEvent for sending tasks to client
local taskEvent = Instance.new("RemoteEvent", ReplicatedStorage)
taskEvent.Name = "TaskEvent"

Players.PlayerAdded:Connect(function(player)
    taskEvent:FireClient(player, TaskModule.Tasks)
end)