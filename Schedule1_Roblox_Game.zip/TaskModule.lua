-- ReplicatedStorage/TaskModule
local TaskModule = {}

-- Sample tasks (title and duration in seconds)
TaskModule.Tasks = {
    { title = "Check Emails", duration = 30 },
    { title = "Team Meeting", duration = 60 },
    { title = "Design Review", duration = 45 },
    { title = "Code Feature", duration = 90 },
    { title = "Deploy Update", duration = 40 },
}

return TaskModule