# Schedule 1 – Roblox Game Prototype

This archive contains the core scripts and instructions for setting up the "Schedule 1 – Roblox" game in Roblox Studio.

## Folder Structure

- **Workspace/Tasks**  
  - (No files here; tasks are defined in TaskModule.lua)
- **ServerScriptService**  
  - `ScheduleServer.lua`
- **ReplicatedStorage**  
  - `TaskModule.lua`
- **StarterGui/ScheduleUI**  
  - `ScheduleClient.lua`

## Installation Steps

1. Unzip this archive to a local folder.
2. Open Roblox Studio and create or open the place **"Schedule 1 – Roblox"**.
3. In the Explorer panel:
   - Create a ModuleScript under **ReplicatedStorage** named `TaskModule`, and paste the contents of `TaskModule.lua`.
   - Create a Script under **ServerScriptService** named `ScheduleServer`, and paste the contents of `ScheduleServer.lua`.
   - Under **StarterGui**, create a ScreenGui named `ScheduleUI`, then add a LocalScript `ScheduleClient` and paste the contents of `ScheduleClient.lua`.
4. Add the UI elements in `ScheduleUI` as described in the main instructions (Frame, TextButtons, Labels).
5. Test the game via **Play Solo** and ensure tasks, timer, and scoring work as expected.

Enjoy prototyping!