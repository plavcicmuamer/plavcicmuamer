-- StarterGui/ScheduleUI/ScheduleClient
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local taskEvent = ReplicatedStorage:WaitForChild("TaskEvent")
local playerGui = game.Players.LocalPlayer:WaitForChild("PlayerGui")
local ui = playerGui:WaitForChild("ScheduleUI")
local taskButtons = ui.Frame:GetChildren()
local timerLabel = ui.TimerLabel
local scoreLabel = ui.ScoreLabel

local tasks = {}
local currentTaskIndex = 1
local score = 0
local timerRunning = false

taskEvent.OnClientEvent:Connect(function(receivedTasks)
    tasks = receivedTasks
    for i, btn in ipairs(taskButtons) do
        if tasks[i] then
            btn.Text = tasks[i].title
            btn.Visible = true
        else
            btn.Visible = false
        end
        btn.MouseButton1Click:Connect(function()
            if not timerRunning and currentTaskIndex == i then
                startTask(tasks[i])
            end
        end)
    end
end)

function startTask(task)
    timerRunning = true
    local timeLeft = task.duration
    timerLabel.Text = timeLeft .. "s"

    local countDown = game:GetService("RunService").Heartbeat:Connect(function(dt)
        timeLeft = timeLeft - dt
        timerLabel.Text = math.floor(timeLeft) .. "s"
        if timeLeft <= 0 then
            countDown:Disconnect()
            completeTask()
        end
    end)
end

function completeTask()
    timerRunning = false
    score = score + 1
    scoreLabel.Text = "Score: " .. score
    currentTaskIndex = currentTaskIndex + 1
    if currentTaskIndex > #tasks then
        ui.Frame.Visible = false
        ui.EndLabel.Visible = true
        ui.EndLabel.Text = "All tasks done! Final Score: " .. score
    end
end